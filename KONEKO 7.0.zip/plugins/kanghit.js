import axios from 'axios'

async function apivisit() {
axios.get(`https://status.pnggilajacn.my.id`);
axios.get(`https://status.pnggilajacn.my.id`);
}
	// By Chandra XD
	// Follow bang
	// TikTok : @pnggilajacn
	// Github : https://github.com/Chandra-XD
export { 
    apivisit 
}
